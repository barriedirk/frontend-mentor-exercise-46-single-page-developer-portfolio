import React, { useEffect, useState } from 'react';
import { TranslatedProject, Translations } from '../data/translations';

interface ProjectModalProps {
  project: TranslatedProject | null;
  initialMode: 'preview' | 'code';
  t: Translations['projects'];
  onClose: () => void;
}

export function ProjectModal({ project, initialMode, t, onClose }: ProjectModalProps) {
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>(initialMode);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setActiveTab(initialMode);
    setCopied(false);
  }, [project, initialMode]);

  useEffect(() => {
    if (!project) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [project, onClose]);

  if (!project) return null;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(project.codeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 md:p-8 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-project-title"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-[#242424] border border-white/15 text-white overflow-hidden max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-white/15 bg-[#151515]">
          <div>
            <h3 id="modal-project-title" className="heading-m uppercase text-white">
              {project.title}
            </h3>
            <div className="flex items-center gap-4 mt-1 text-sm text-[#D9D9D9] font-medium">
              {project.tags.map((tag, idx) => (
                <React.Fragment key={tag}>
                  <span>{tag}</span>
                  {idx < project.tags.length - 1 && <span aria-hidden="true">·</span>}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex items-center gap-4">
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`text-sm font-bold tracking-[2px] uppercase pb-1 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'preview'
                    ? 'text-[#4EE1A0] border-[#4EE1A0]'
                    : 'text-[#D9D9D9] border-transparent hover:text-white'
                }`}
              >
                {t.viewProject}
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('code')}
                className={`text-sm font-bold tracking-[2px] uppercase pb-1 border-b-2 transition-colors cursor-pointer ${
                  activeTab === 'code'
                    ? 'text-[#4EE1A0] border-[#4EE1A0]'
                    : 'text-[#D9D9D9] border-transparent hover:text-white'
                }`}
              >
                {t.viewCode}
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              aria-label="Close modal"
              className="w-10 h-10 flex items-center justify-center text-white hover:text-[#4EE1A0] transition-colors text-2xl font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6">
          {activeTab === 'preview' ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              <div className="lg:col-span-7 bg-[#151515] overflow-hidden border border-white/10">
                <img
                  src={project.image}
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
              </div>

              <div className="lg:col-span-5 space-y-6">
                <div>
                  <h4 className="text-sm font-bold tracking-[2px] uppercase text-[#4EE1A0] mb-2">
                    {t.projectOverview}
                  </h4>
                  <p className="body-l text-[#D9D9D9]">{project.summary}</p>
                </div>

                <div>
                  <h4 className="text-sm font-bold tracking-[2px] uppercase text-[#4EE1A0] mb-3">
                    {t.architectureHighlights}
                  </h4>
                  <ul className="space-y-2.5 text-[#D9D9D9] text-base leading-relaxed">
                    {project.highlights.map((item) => (
                      <li key={item} className="flex items-start gap-3">
                        <span className="text-[#4EE1A0] font-bold">—</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-4 border-t border-white/15 flex flex-wrap items-center gap-8">
                  <button
                    type="button"
                    onClick={() => setActiveTab('code')}
                    className="btn-underline"
                  >
                    {t.inspectSource}
                  </button>
                  <button
                    type="button"
                    onClick={onClose}
                    className="btn-underline"
                  >
                    {t.backToPortfolio}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold tracking-[2px] uppercase text-[#4EE1A0]">
                    {t.coreSnippet}
                  </h4>
                  <p className="text-sm text-[#D9D9D9] mt-1">
                    {t.snippetSubtitle(project.title)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="btn-underline text-sm"
                >
                  {copied ? t.copiedSnippet : t.copySnippet}
                </button>
              </div>

              <pre className="bg-[#151515] p-6 border border-white/15 overflow-x-auto text-sm md:text-base font-mono text-[#D9D9D9] leading-relaxed">
                <code>{project.codeSnippet}</code>
              </pre>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                {project.highlights.map((highlight, index) => (
                  <div key={highlight} className="bg-[#151515] p-5 border border-white/10">
                    <div className="text-xs font-bold tracking-[2px] text-[#4EE1A0] uppercase mb-2">
                      {t.specificationIndex(index + 1)}
                    </div>
                    <p className="text-sm text-[#D9D9D9] leading-relaxed">{highlight}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
