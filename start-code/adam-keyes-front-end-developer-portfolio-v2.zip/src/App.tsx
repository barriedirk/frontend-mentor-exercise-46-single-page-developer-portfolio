/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import {
  HERO_PORTRAIT_IMAGE,
} from './data/projects';
import {
  Language,
  TRANSLATIONS,
  TranslatedProject,
} from './data/translations';
import {
  IconErrorExclamation,
  IconFrontendMentor,
  IconGitHub,
  IconLinkedIn,
  IconTwitter,
  PatternCircle,
  PatternRings,
} from './components/Icons';
import { ProjectModal } from './components/ProjectModal';
import { DesignSystemModal } from './components/DesignSystemModal';
import { ScrollDrivenHeroVideo } from './components/ScrollDrivenHeroVideo';

interface FormValues {
  name: string;
  email: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  message?: string;
}

const SOCIAL_LINKS = [
  {
    name: 'GitHub',
    href: 'https://github.com',
    icon: IconGitHub,
  },
  {
    name: 'Frontend Mentor',
    href: 'https://www.frontendmentor.io',
    icon: IconFrontendMentor,
  },
  {
    name: 'LinkedIn',
    href: 'https://www.linkedin.com',
    icon: IconLinkedIn,
  },
  {
    name: 'Twitter',
    href: 'https://twitter.com',
    icon: IconTwitter,
  },
];

export default function App() {
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const contactSectionRef = useRef<HTMLElement | null>(null);

  // Language state (default 'en' per Frontend Mentor challenge, or user preference)
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('adam_keyes_lang');
      if (saved === 'es' || saved === 'en') return saved;
    } catch {
      // Ignore localStorage access issues
    }
    return 'en';
  });

  const t = TRANSLATIONS[lang];

  useEffect(() => {
    try {
      localStorage.setItem('adam_keyes_lang', lang);
      document.documentElement.lang = lang;
    } catch {
      // Ignore localStorage access issues
    }
  }, [lang]);

  const [selectedProject, setSelectedProject] = useState<TranslatedProject | null>(null);
  const [modalMode, setModalMode] = useState<'preview' | 'code'>('preview');
  const [isDesignSystemOpen, setIsDesignSystemOpen] = useState(false);

  // Contact form state
  const [formValues, setFormValues] = useState<FormValues>({
    name: '',
    email: '',
    message: '',
  });
  const [touched, setTouched] = useState<Record<keyof FormValues, boolean>>({
    name: false,
    email: false,
    message: false,
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  // Re-sync selected project when language changes
  useEffect(() => {
    if (selectedProject) {
      const updated = t.projects.list.find((p) => p.id === selectedProject.id);
      if (updated) setSelectedProject(updated);
    }
  }, [lang, t.projects.list, selectedProject]);

  const validateField = (field: keyof FormValues, value: string): string | undefined => {
    const trimmed = value.trim();
    if (field === 'name') {
      if (!trimmed) return t.contact.errors.required;
      return undefined;
    }
    if (field === 'email') {
      if (!trimmed) return t.contact.errors.required;
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(trimmed)) return t.contact.errors.invalidEmail;
      return undefined;
    }
    if (field === 'message') {
      if (!trimmed) return t.contact.errors.required;
      return undefined;
    }
    return undefined;
  };

  const validateAll = (values: FormValues): FormErrors => {
    const nextErrors: FormErrors = {};
    const nameErr = validateField('name', values.name);
    const emailErr = validateField('email', values.email);
    const msgErr = validateField('message', values.message);
    if (nameErr) nextErrors.name = nameErr;
    if (emailErr) nextErrors.email = emailErr;
    if (msgErr) nextErrors.message = msgErr;
    return nextErrors;
  };

  const handleInputChange = (field: keyof FormValues, value: string) => {
    const nextValues = { ...formValues, [field]: value };
    setFormValues(nextValues);
    if (submittedMessage) setSubmittedMessage(null);

    if (touched[field]) {
      const fieldError = validateField(field, value);
      setErrors((prev) => ({
        ...prev,
        [field]: fieldError,
      }));
    }
  };

  const handleInputBlur = (field: keyof FormValues) => {
    setTouched((prev) => ({ ...prev, [field]: true }));
    const fieldError = validateField(field, formValues[field]);
    setErrors((prev) => ({
      ...prev,
      [field]: fieldError,
    }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ name: true, email: true, message: true });
    const validationErrors = validateAll(formValues);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setSubmittedMessage(t.contact.successMessage(formValues.name.trim()));
      setFormValues({ name: '', email: '', message: '' });
      setTouched({ name: false, email: false, message: false });
      setErrors({});
    }
  };

  const scrollToContact = () => {
    contactSectionRef.current?.scrollIntoView({ behavior: 'smooth' });
    setTimeout(() => {
      nameInputRef.current?.focus();
    }, 450);
  };

  const openProjectModal = (project: TranslatedProject, mode: 'preview' | 'code') => {
    setSelectedProject(project);
    setModalMode(mode);
  };

  const getBorderClass = (field: keyof FormValues) => {
    if (touched[field] && errors[field]) {
      return 'border-[#FF6F5B] focus:border-[#FF6F5B]';
    }
    if (formValues[field].trim().length > 0 && !errors[field]) {
      return 'border-[#4EE1A0] focus:border-[#4EE1A0]';
    }
    return 'border-white/60 focus:border-[#4EE1A0]';
  };

  return (
    <div className="min-h-screen bg-[#151515] text-white relative overflow-x-hidden">
      {/* HERO & HEADER WRAPPER */}
      <div className="relative max-w-[1110px] mx-auto px-4 md:px-8 lg:px-0">
        {/* Decorative Rings Top-Left */}
        <PatternRings className="absolute -left-[342px] top-[124px] md:-left-[265px] md:top-[86px] lg:-left-[265px] lg:top-[133px] z-0" />

        {/* HEADER */}
        <header className="relative z-30 pt-5 md:pt-[29px] lg:pt-[39px] flex flex-col md:flex-row items-center justify-between gap-5">
          <a
            href="#top"
            className="text-[24px] md:text-[32px] leading-[32px] font-bold tracking-[-0.33px] md:tracking-[-0.44px] text-white whitespace-nowrap shrink-0"
          >
            {t.header.logo}
          </a>

          <div className="flex items-center gap-6 md:gap-8 md:pr-[30px]">
            {/* Social Media Links */}
            <nav aria-label={t.header.socialAria} className="flex items-center gap-5 md:gap-6">
              {SOCIAL_LINKS.map((item) => {
                const IconComponent = item.icon;
                return (
                  <a
                    key={item.name}
                    href={item.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={item.name}
                    className="text-white hover:text-[#4EE1A0] focus-visible:text-[#4EE1A0] transition-colors duration-150"
                  >
                    <IconComponent className="w-5 h-5 md:w-6 md:h-6" />
                  </a>
                );
              })}
            </nav>

            {/* Language Switcher (Discreet EN / ES) */}
            <div
              role="group"
              aria-label={t.header.langToggleAria}
              className="flex items-center text-[14px] md:text-[15px] font-bold tracking-[1.5px] uppercase pl-2 border-l border-white/20"
            >
              <button
                type="button"
                onClick={() => setLang('en')}
                aria-pressed={lang === 'en'}
                className={`transition-colors cursor-pointer pb-0.5 ${
                  lang === 'en'
                    ? 'text-[#4EE1A0] border-b-2 border-[#4EE1A0]'
                    : 'text-[#D9D9D9]/60 hover:text-white'
                }`}
              >
                EN
              </button>
              <span className="mx-2 text-white/30" aria-hidden="true">
                /
              </span>
              <button
                type="button"
                onClick={() => setLang('es')}
                aria-pressed={lang === 'es'}
                className={`transition-colors cursor-pointer pb-0.5 ${
                  lang === 'es'
                    ? 'text-[#4EE1A0] border-b-2 border-[#4EE1A0]'
                    : 'text-[#D9D9D9]/60 hover:text-white'
                }`}
              >
                ES
              </button>
            </div>
          </div>
        </header>

        {/* HERO SECTION */}
        <section
          id="top"
          aria-label="Introduction"
          className="relative pb-20 md:pb-[60px] lg:pb-[104px] md:min-h-[540px] lg:min-h-[652px]"
        >
          {/* Portrait Container with Scroll-Driven Video */}
          <div className="relative mx-auto -mt-[92px] w-[174px] h-[383px] md:mt-0 md:mx-0 md:absolute md:-top-[62px] md:-right-8 md:w-[322px] md:h-[600px] lg:-top-[72px] lg:right-0 lg:w-[445px] lg:h-[720px] bg-gradient-to-b from-[#242424]/40 via-[#242424] to-[#242424] z-10 flex items-end overflow-visible">
            <ScrollDrivenHeroVideo
              fallbackImage={HERO_PORTRAIT_IMAGE}
              alt={t.hero.portraitAlt}
            />

            {/* Decorative Circle overlapping portrait edge */}
            <PatternCircle className="absolute -right-[64px] bottom-0 md:-right-[64px] md:bottom-0 lg:right-auto lg:-left-[64.5px] lg:bottom-[70px] z-20" />
          </div>

          {/* Hero Copy Block */}
          <div className="relative z-20 mt-10 md:mt-0 md:pt-[90px] lg:pt-[127px] text-center md:text-left max-w-[445px] md:max-w-[445px] lg:max-w-[706px] mx-auto md:mx-0">
            <h1 className="heading-xl text-white">
              <span className="block lg:inline">{t.hero.greetingLine1}</span>
              <span className="block lg:inline">{t.hero.greetingLine2}</span>
              <span className="inline">{t.hero.imPrefix}</span>
              <span className="inline-block border-b-4 md:border-b-[6px] border-[#4EE1A0] pb-0.5 md:pb-1.5">
                {t.hero.name}
              </span>
              <span>{t.hero.dot}</span>
            </h1>

            <p className="body-l text-[#D9D9D9] mt-6 md:mt-[60px] lg:mt-[43px] mb-6 md:mb-[34px] lg:mb-[66px] max-w-[445px] mx-auto md:mx-0">
              {t.hero.bio}
            </p>

            <div>
              <button
                type="button"
                onClick={scrollToContact}
                className="btn-underline"
              >
                {t.hero.contactBtn}
              </button>
            </div>
          </div>
        </section>

        {/* SKILLS SECTION */}
        <section
          aria-label={t.skills.sectionAria}
          className="relative border-t border-white/25 border-b md:border-b-0 py-10 md:pt-[52px] md:pb-0 lg:pt-[72px] mb-20 md:mb-[100px] lg:mb-[140px]"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-6 md:gap-y-[52px] lg:gap-y-[58px] md:gap-x-6 lg:gap-x-[30px] text-center md:text-left">
            {t.skills.skills.map((skill) => (
              <div key={skill.name}>
                <h2 className="heading-l text-white mb-0.5 md:mb-[14px]">
                  {skill.name}
                </h2>
                <p className="body-l text-[#D9D9D9]">{t.skills.yearsExperience(skill.years)}</p>
              </div>
            ))}
          </div>

          {/* Decorative Rings Bottom-Right of Skills */}
          <PatternRings className="absolute -right-[344px] -bottom-[64px] md:-right-[332px] md:-bottom-[64px] lg:-right-[404px] lg:-bottom-[50px] z-0" />
        </section>

        {/* PROJECTS SECTION */}
        <section
          id="projects"
          aria-labelledby="projects-heading"
          className="pb-20 md:pb-[100px] lg:pb-[139px]"
        >
          {/* Section Header */}
          <div className="flex items-center justify-between mb-10 md:mb-[60px] lg:mb-20">
            <h2 id="projects-heading" className="heading-xl text-white">
              {t.projects.sectionTitle}
            </h2>
            <button
              type="button"
              onClick={scrollToContact}
              className="btn-underline"
            >
              {t.projects.contactBtn}
            </button>
          </div>

          {/* Projects 2-Column Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-y-10 md:gap-y-[60px] lg:gap-y-[69px] md:gap-x-6 lg:gap-x-[30px]">
            {t.projects.list.map((project) => (
              <article key={project.id} className="group flex flex-col">
                {/* Project Thumbnail Container with Desktop Hover Overlay */}
                <div
                  tabIndex={0}
                  onClick={() => openProjectModal(project, 'preview')}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      openProjectModal(project, 'preview');
                    }
                  }}
                  className="relative aspect-[540/400] w-full bg-[#242424] overflow-hidden cursor-pointer focus:outline-2 focus:outline-[#4EE1A0]"
                >
                  <img
                    src={project.image}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-200 ease-out lg:group-hover:scale-[1.02]"
                  />

                  {/* Desktop Hover / Focus Overlay (lg and up) */}
                  <div
                    onClick={(e) => e.stopPropagation()}
                    className="hidden lg:flex absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 group-focus-within:opacity-100 transition-opacity duration-150 flex-col items-center justify-center gap-12"
                  >
                    <button
                      type="button"
                      onClick={() => openProjectModal(project, 'preview')}
                      className="btn-underline"
                    >
                      {t.projects.viewProject}
                    </button>
                    <button
                      type="button"
                      onClick={() => openProjectModal(project, 'code')}
                      className="btn-underline"
                    >
                      {t.projects.viewCode}
                    </button>
                  </div>
                </div>

                {/* Project Title */}
                <h3 className="heading-m text-white uppercase mt-5">
                  {project.title}
                </h3>

                {/* Project Tech Tags */}
                <div className="flex items-center gap-[18px] mt-[7px] text-[18px] leading-[28px] font-medium text-[#D9D9D9] uppercase">
                  {project.tags.map((tag) => (
                    <span key={tag}>{tag}</span>
                  ))}
                </div>

                {/* Mobile & Tablet Permanent Action Links */}
                <div className="flex lg:hidden items-center gap-[30px] mt-5">
                  <button
                    type="button"
                    onClick={() => openProjectModal(project, 'preview')}
                    className="btn-underline"
                  >
                    {t.projects.viewProject}
                  </button>
                  <button
                    type="button"
                    onClick={() => openProjectModal(project, 'code')}
                    className="btn-underline"
                  >
                    {t.projects.viewCode}
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>

      {/* CONTACT & FOOTER SECTION */}
      <footer
        ref={contactSectionRef}
        id="contact"
        className="relative bg-[#242424] pt-[60px] lg:pt-[84px] pb-[60px] md:pb-10 lg:pb-[92px] overflow-hidden"
      >
        <div className="relative max-w-[1110px] mx-auto px-4 md:px-8 lg:px-0">
          {/* Decorative Rings Bottom-Left of Contact */}
          <PatternRings className="absolute -left-[343px] bottom-[97px] md:-left-[368px] md:bottom-[27px] lg:-left-[370px] lg:bottom-[47px] z-0" />

          {/* Contact Split Container */}
          <div className="relative z-10 flex flex-col lg:flex-row items-center lg:items-start justify-between gap-12 lg:gap-8 pb-[87px] md:pb-[92px]">
            {/* Contact Intro Copy */}
            <div className="w-full max-w-[445px] text-center lg:text-left">
              <h2 className="heading-xl text-white">{t.contact.title}</h2>
              <p className="body-l text-[#D9D9D9] mt-5 lg:mt-9">
                {t.contact.description}
              </p>
            </div>

            {/* Contact Form */}
            <form
              noValidate
              onSubmit={handleFormSubmit}
              className="w-full max-w-[445px] space-y-8"
            >
              {/* NAME FIELD */}
              <div>
                <div className="relative">
                  <input
                    ref={nameInputRef}
                    id="contact-name"
                    name="name"
                    type="text"
                    placeholder={t.contact.namePlaceholder}
                    aria-label={t.contact.namePlaceholder}
                    aria-invalid={Boolean(touched.name && errors.name)}
                    aria-describedby={touched.name && errors.name ? 'name-error' : undefined}
                    value={formValues.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    onBlur={() => handleInputBlur('name')}
                    className={`w-full bg-transparent pb-4 pl-6 pr-10 border-b ${getBorderClass(
                      'name'
                    )} text-white placeholder:text-white/50 text-[16px] leading-[26px] tracking-[-0.22px] font-medium uppercase focus:outline-none transition-colors`}
                  />
                  {touched.name && errors.name && (
                    <IconErrorExclamation className="w-6 h-6 absolute right-0 top-0" />
                  )}
                </div>
                {touched.name && errors.name && (
                  <p
                    id="name-error"
                    role="alert"
                    className="text-[12px] leading-[16px] tracking-[-0.17px] text-[#FF6F5B] text-right mt-[5px]"
                  >
                    {errors.name}
                  </p>
                )}
              </div>

              {/* EMAIL FIELD */}
              <div>
                <div className="relative">
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    placeholder={t.contact.emailPlaceholder}
                    aria-label={t.contact.emailPlaceholder}
                    aria-invalid={Boolean(touched.email && errors.email)}
                    aria-describedby={touched.email && errors.email ? 'email-error' : undefined}
                    value={formValues.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    onBlur={() => handleInputBlur('email')}
                    className={`w-full bg-transparent pb-4 pl-6 pr-10 border-b ${getBorderClass(
                      'email'
                    )} text-white placeholder:text-white/50 text-[16px] leading-[26px] tracking-[-0.22px] font-medium uppercase focus:outline-none transition-colors`}
                  />
                  {touched.email && errors.email && (
                    <IconErrorExclamation className="w-6 h-6 absolute right-0 top-0" />
                  )}
                </div>
                {touched.email && errors.email && (
                  <p
                    id="email-error"
                    role="alert"
                    className="text-[12px] leading-[16px] tracking-[-0.17px] text-[#FF6F5B] text-right mt-[5px]"
                  >
                    {errors.email}
                  </p>
                )}
              </div>

              {/* MESSAGE FIELD */}
              <div>
                <div className="relative">
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={4}
                    placeholder={t.contact.messagePlaceholder}
                    aria-label={t.contact.messagePlaceholder}
                    aria-invalid={Boolean(touched.message && errors.message)}
                    aria-describedby={
                      touched.message && errors.message ? 'message-error' : undefined
                    }
                    value={formValues.message}
                    onChange={(e) => handleInputChange('message', e.target.value)}
                    onBlur={() => handleInputBlur('message')}
                    className={`w-full bg-transparent pb-4 pl-6 pr-10 border-b ${getBorderClass(
                      'message'
                    )} text-white placeholder:text-white/50 text-[16px] leading-[26px] tracking-[-0.22px] font-medium uppercase resize-none focus:outline-none transition-colors`}
                  />
                  {touched.message && errors.message && (
                    <IconErrorExclamation className="w-6 h-6 absolute right-0 top-0" />
                  )}
                </div>
                {touched.message && errors.message && (
                  <p
                    id="message-error"
                    role="alert"
                    className="text-[12px] leading-[16px] tracking-[-0.17px] text-[#FF6F5B] text-right mt-[5px]"
                  >
                    {errors.message}
                  </p>
                )}
              </div>

              {/* Confirmation message upon valid submission */}
              {submittedMessage && (
                <div
                  role="status"
                  className="p-4 bg-[#151515] border border-[#4EE1A0] text-[#4EE1A0] text-sm font-medium"
                >
                  {submittedMessage}
                </div>
              )}

              {/* SEND MESSAGE BUTTON */}
              <div className="flex justify-end pt-1">
                <button type="submit" className="btn-underline">
                  {t.contact.sendBtn}
                </button>
              </div>
            </form>
          </div>

          {/* BOTTOM FOOTER BAR */}
          <div className="relative z-10 border-t border-white/25 pt-10 md:pt-[30px] lg:pt-[47px] flex flex-col md:flex-row items-center justify-between gap-5">
            <div className="flex items-center gap-6">
              <a
                href="#top"
                className="text-[24px] md:text-[32px] leading-[32px] font-bold tracking-[-0.33px] md:tracking-[-0.44px] text-white whitespace-nowrap shrink-0"
              >
                {t.footer.logo}
              </a>
              <button
                type="button"
                onClick={() => setIsDesignSystemOpen(true)}
                className="text-xs font-bold tracking-[1.5px] uppercase text-[#D9D9D9]/50 hover:text-[#4EE1A0] transition-colors cursor-pointer"
              >
                {t.footer.designSystemBtn}
              </button>
            </div>

            <div className="flex items-center gap-6 md:gap-8">
              <nav aria-label={t.footer.socialAria} className="flex items-center gap-6 md:gap-8">
                {SOCIAL_LINKS.map((item) => {
                  const IconComponent = item.icon;
                  return (
                    <a
                      key={item.name}
                      href={item.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={item.name}
                      className="text-white hover:text-[#4EE1A0] focus-visible:text-[#4EE1A0] transition-colors duration-150"
                    >
                      <IconComponent className="w-5 h-5 md:w-6 md:h-6" />
                    </a>
                  );
                })}
              </nav>

              {/* Footer Language Switcher */}
              <div
                role="group"
                aria-label={t.header.langToggleAria}
                className="flex items-center text-[13px] font-bold tracking-[1.5px] uppercase pl-2 border-l border-white/20"
              >
                <button
                  type="button"
                  onClick={() => setLang('en')}
                  aria-pressed={lang === 'en'}
                  className={`transition-colors cursor-pointer pb-0.5 ${
                    lang === 'en'
                      ? 'text-[#4EE1A0] border-b-2 border-[#4EE1A0]'
                      : 'text-[#D9D9D9]/60 hover:text-white'
                  }`}
                >
                  EN
                </button>
                <span className="mx-2 text-white/30" aria-hidden="true">
                  /
                </span>
                <button
                  type="button"
                  onClick={() => setLang('es')}
                  aria-pressed={lang === 'es'}
                  className={`transition-colors cursor-pointer pb-0.5 ${
                    lang === 'es'
                      ? 'text-[#4EE1A0] border-b-2 border-[#4EE1A0]'
                      : 'text-[#D9D9D9]/60 hover:text-white'
                  }`}
                >
                  ES
                </button>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Project Preview / Code Modal */}
      <ProjectModal
        project={selectedProject}
        initialMode={modalMode}
        t={t.projects}
        onClose={() => setSelectedProject(null)}
      />

      {/* Interactive Design System Reference Modal */}
      <DesignSystemModal
        isOpen={isDesignSystemOpen}
        t={t.designSystem}
        onClose={() => setIsDesignSystemOpen(false)}
      />
    </div>
  );
}
